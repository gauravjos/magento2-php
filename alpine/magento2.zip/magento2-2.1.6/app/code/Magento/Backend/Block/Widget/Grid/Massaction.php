<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Grid widget massaction default block
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 */
namespace Magento\Backend\Block\Widget\Grid;

class Massaction extends \Magento\Backend\Block\Widget\Grid\Massaction\AbstractMassaction
{
}
